# Random Quote Generator 🧠✨

A simple Python script that prints a random motivational quote every time you run it.

## Features

- Picks a quote at random from a list.
- Lightweight and easy to run.

## How to Use

1. Make sure you have Python installed.
2. Clone the repo or copy the `main.py` file.
3. Run the script:

```bash
python main.py
```

Enjoy your daily dose of motivation! 💪

## License

This project is licensed under the MIT License.
